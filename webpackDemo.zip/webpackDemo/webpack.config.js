const path = require('path');
const nodeExternals = require('webpack-node-externals');
module.exports = {
    mode: 'development', // or 'production'
    entry: './index.js',
    externals: [nodeExternals()],
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist'),
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env'],
                    },
                },
            },
            {
                test: /\.(png|svg|jpg|jpeg|gif)$/i,
                type: 'asset/resource',
            },
        ],
    },
    resolve: {
      fallback: {
          "async_hooks": require.resolve("async_hooks"),
          "zlib": require.resolve("browserify-zlib"),
          "querystring": require.resolve("querystring-es3"),
          "crypto": require.resolve("crypto-browserify"),
          "stream": require.resolve("stream-browserify"),
          "http": require.resolve("stream-http"),
          "url": require.resolve("url"),
          "util": require.resolve("util"),
          "string_decoder": require.resolve("string_decoder"),
          "buffer": require.resolve("buffer"),
          "path": require.resolve("path-browserify"),
      },
  },
  
  
  
};
