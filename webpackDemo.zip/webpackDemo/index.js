

const path = require('path');
const express = require('express');
const app =express();
app.use(express.json());

const indexPath = path.join(__dirname, 'public', 'index.html');

app.get('/',(req, res)=>{
  res.send('prakash');
})



app.listen(4000, () => {
  console.log('Server listening on http://localhost:4000 ...');
});